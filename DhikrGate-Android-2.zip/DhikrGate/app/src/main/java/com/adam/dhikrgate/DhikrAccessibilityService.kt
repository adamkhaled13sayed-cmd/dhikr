package com.adam.dhikrgate

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class DhikrAccessibilityService : AccessibilityService() {

    private var lastPkg = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == lastPkg) return          // نفس التطبيق، لا تكرر
        lastPkg = pkg

        if (shouldSkip(pkg)) return
        if (Prefs.isUnlocked(this, pkg)) return

        startActivity(
            Intent(this, GateActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                .putExtra("target", pkg)
        )
    }

    // لا نعترض التطبيق نفسه ولا الواجهة والكيبورد والمشغّل ولا الاتصال الطارئ
    private fun shouldSkip(pkg: String): Boolean {
        if (pkg == packageName || pkg == "com.android.systemui") return true
        if (pkg.contains("inputmethod") || pkg.contains("keyboard")) return true
        if (pkg.contains("dialer") || pkg.contains("emergency")) return true
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val launcher = packageManager.resolveActivity(home, 0)?.activityInfo?.packageName
        return pkg == launcher
    }

    override fun onInterrupt() {}
}
