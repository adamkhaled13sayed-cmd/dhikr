package com.adam.dhikrgate

import android.content.Context

object Prefs {
    private const val FILE = "dhikr_gate"
    private val unlockedAt = HashMap<String, Long>()

    fun count(c: Context) = c.getSharedPreferences(FILE, 0).getInt("count", 10)
    fun setCount(c: Context, v: Int) = c.getSharedPreferences(FILE, 0).edit().putInt("count", v).apply()

    // كم دقيقة يبقى التطبيق مفتوحًا بعد الذكر قبل ما يطلب منك من جديد
    fun graceMin(c: Context) = c.getSharedPreferences(FILE, 0).getInt("grace", 5)
    fun setGraceMin(c: Context, v: Int) = c.getSharedPreferences(FILE, 0).edit().putInt("grace", v).apply()

    fun markUnlocked(pkg: String) { unlockedAt[pkg] = System.currentTimeMillis() }
    fun isUnlocked(c: Context, pkg: String): Boolean {
        val t = unlockedAt[pkg] ?: return false
        return System.currentTimeMillis() - t < graceMin(c) * 60_000L
    }
}
