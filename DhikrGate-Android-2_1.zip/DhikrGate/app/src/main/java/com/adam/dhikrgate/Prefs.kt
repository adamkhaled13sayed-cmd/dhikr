package com.adam.dhikrgate

import android.content.Context

object Prefs {
    private const val FILE = "dhikr_gate"
    const val UNTIL_EXIT = 0   // القيمة 0 تعني: يبقى مفتوحًا حتى تخرج من التطبيق
    private val unlockedAt = HashMap<String, Long>()

    fun count(c: Context) = c.getSharedPreferences(FILE, 0).getInt("count", 10)
    fun setCount(c: Context, v: Int) = c.getSharedPreferences(FILE, 0).edit().putInt("count", v).apply()

    fun graceMin(c: Context) = c.getSharedPreferences(FILE, 0).getInt("grace", 5)
    fun setGraceMin(c: Context, v: Int) = c.getSharedPreferences(FILE, 0).edit().putInt("grace", v).apply()

    fun markUnlocked(pkg: String) { unlockedAt[pkg] = System.currentTimeMillis() }
    fun lock(pkg: String) { unlockedAt.remove(pkg) }

    fun isUnlocked(c: Context, pkg: String): Boolean {
        val t = unlockedAt[pkg] ?: return false
        val g = graceMin(c)
        if (g == UNTIL_EXIT) return true
        return System.currentTimeMillis() - t < g * 60_000L
    }
}
