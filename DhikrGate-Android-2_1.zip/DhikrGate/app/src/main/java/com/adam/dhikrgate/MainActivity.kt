package com.adam.dhikrgate

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(48, 96, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "🤲 ذكّرني"; textSize = 28f; gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "فعّل الخدمة من إعدادات إمكانية الوصول، ثم اختر عدد مرات الذكر قبل فتح أي تطبيق."
            textSize = 15f; setPadding(0, 32, 0, 32)
        })
        root.addView(Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        fun picker(label: String, values: List<Int>, names: List<String>,
                   get: () -> Int, set: (Int) -> Unit) {
            root.addView(TextView(this).apply { text = label; setPadding(0, 40, 0, 8) })
            root.addView(Spinner(this).apply {
                adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, names)
                setSelection(values.indexOf(get()).coerceAtLeast(0))
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = set(values[pos])
                    override fun onNothingSelected(p: AdapterView<*>?) {}
                }
            })
        }

        val counts = listOf(1, 3, 10, 33)
        picker("عدد مرات الذكر", counts, counts.map { it.toString() },
            { Prefs.count(this) }) { Prefs.setCount(this, it) }

        val graces = listOf(Prefs.UNTIL_EXIT, 1, 5, 15, 30)
        val graceNames = listOf("حتى الخروج من التطبيق", "1 دقيقة", "5 دقائق", "15 دقيقة", "30 دقيقة")
        picker("مدة بقاء التطبيق مفتوحًا بعد الذكر", graces, graceNames,
            { Prefs.graceMin(this) }) { Prefs.setGraceMin(this, it) }

        setContentView(root)
    }
}
