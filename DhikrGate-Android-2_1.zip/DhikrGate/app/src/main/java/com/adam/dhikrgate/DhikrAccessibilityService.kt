package com.adam.dhikrgate

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class DhikrAccessibilityService : AccessibilityService() {

    private var lastPkg = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return

        // نتجاهل تطبيقنا والواجهة والكيبورد دون أن نعتبرها خروجًا من التطبيق
        if (pkg == lastPkg || pkg == packageName || isIgnored(pkg)) return

        // انتقال حقيقي إلى تطبيق آخر (أو إلى الشاشة الرئيسية)
        val prev = lastPkg
        lastPkg = pkg

        // وضع "حتى الخروج": عند مغادرة التطبيق السابق نقفله من جديد
        if (prev.isNotEmpty() && Prefs.graceMin(this) == Prefs.UNTIL_EXIT) Prefs.lock(prev)

        if (isLauncher(pkg)) return
        if (Prefs.isUnlocked(this, pkg)) return

        startActivity(
            Intent(this, GateActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                .putExtra("target", pkg)
        )
    }

    private fun isIgnored(pkg: String): Boolean =
        pkg == "com.android.systemui" ||
        pkg.contains("inputmethod") || pkg.contains("keyboard") ||
        pkg.contains("dialer") || pkg.contains("emergency")

    private fun isLauncher(pkg: String): Boolean {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return packageManager.resolveActivity(home, 0)?.activityInfo?.packageName == pkg
    }

    override fun onInterrupt() {}
}
