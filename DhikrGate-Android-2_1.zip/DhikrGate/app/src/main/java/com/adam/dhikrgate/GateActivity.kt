package com.adam.dhikrgate

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

class GateActivity : Activity() {

    private val azkar = listOf(
        "سبحان الله", "الحمد لله", "الله أكبر",
        "لا إله إلا الله", "أستغفر الله", "سبحان الله وبحمده"
    )
    private var done = 0
    private var total = 10
    private lateinit var target: String

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        target = intent.getStringExtra("target") ?: run { finish(); return }
        total = Prefs.count(this)

        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(target, 0))
        } catch (e: Exception) { target }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#F4F1EA"))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(48, 48, 48, 48)
        }
        fun tv(text: String, size: Float, color: String, bold: Boolean = false) =
            TextView(this).apply {
                this.text = text; textSize = size; gravity = Gravity.CENTER
                setTextColor(Color.parseColor(color))
                if (bold) setTypeface(null, Typeface.BOLD)
            }

        root.addView(tv("قبل فتح $appName قل:", 16f, "#6B7A72"))
        root.addView(tv(azkar.random(), 34f, "#1F7A5A", true).apply { setPadding(0, 32, 0, 32) })

        val btn = Button(this).apply {
            text = "0"; textSize = 44f; setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#1F7A5A"))
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = total; progress = 0
        }
        btn.setOnClickListener {
            done++
            btn.text = done.toString()
            bar.progress = done
            btn.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            if (done >= total) unlockAndOpen()
        }
        root.addView(btn, LinearLayout.LayoutParams(520, 520))
        root.addView(bar, LinearLayout.LayoutParams(600, 40).apply { topMargin = 48 })
        root.addView(Button(this).apply {
            text = "إلغاء"; setOnClickListener { goHome() }
        })
        setContentView(root)
    }

    private fun unlockAndOpen() {
        Prefs.markUnlocked(target)
        packageManager.getLaunchIntentForPackage(target)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
        finish()
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    override fun onBackPressed() = goHome()
}
